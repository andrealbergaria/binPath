# binPath
binary representaion program, creates binary numbers very fast (useful for many things)

This program runs combination of binary numbers very fast...useful for decrypting AES ciphers and others and brute force things...
This has multiple uses...
Of course it needs to be customized (currently only 6 bits are used), if you want you can upgrade it :)

later


